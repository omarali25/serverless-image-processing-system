# Serverless Image Processing System

## Project Overview

This project demonstrates a simple serverless image processing workflow using AWS services.

When a user uploads an image to Amazon S3, the system automatically starts an image processing workflow. The request is sent to Amazon SQS, then AWS Step Functions trigger an AWS Lambda function to process the image. After processing, the image is stored in another S3 bucket.

## AWS Services Used

- Amazon S3
- Amazon SQS
- AWS Lambda
- AWS Step Functions

## Architecture

User → S3 Upload Bucket → SQS Queue → Step Functions → Lambda → S3 Processed Bucket

## Workflow

1. User uploads image to S3.
2. S3 creates an event notification.
3. A message is sent to SQS.
4. Step Functions starts the workflow.
5. Lambda processes the image.
6. Processed image is stored in another S3 bucket.

## Project Structure

